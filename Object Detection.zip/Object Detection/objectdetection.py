import cv2
import matplotlib.pyplot as plt
from PIL import Image
from random import randint
import numpy as np 
import tensorflow as tf
model = tf.saved_model.load('ssd_mobilenet_v2_fpnlite_640x640_coco17_tpu-8/saved_model')

img = Image.open("bus.jpeg")
img_arr = np.array(img)
input_tensor = tf.convert_to_tensor(np.expand_dims(img_arr,0))
image_detection = model(input_tensor)
boxes = image_detection['detection_boxes'].numpy()
classes = image_detection['detection_classes'].numpy().astype(int)
scores =  image_detection['detection_scores'].numpy()



labels = ['background', 'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus',
		'train', 'truck', 'boat', 'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 
		'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 
		'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 
		'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard',
		'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana',
		'apple', 'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 
		'chair', 'couch', 'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse',
		'remote', 'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator',
		'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush']

for i in range(classes.shape[1]):
    class_id = int(classes[0,i])
    score = scores[0,i]
    if np.any(score > 0.5):
        h,w,_ = img_arr.shape
        ymin,xmin,ymax,xmax = boxes[0,i]
        xmin = int(xmin*w)
        xmax= int(xmax*w)
        ymin = int(ymin * h)
        ymax = int(ymax * h)
        class_name = labels[class_id]
        random_color = (randint(0,256),randint(0,256),randint(0,256))
        label = f"class:{class_name},score :{score}"
        cv2.putText(img_arr,label,(xmin,ymin-2),cv2.FONT_HERSHEY_SIMPLEX,0.7,random_color,2)

plt.imshow(img_arr)
plt.axis('off')
plt.show()


